#import "Drawzb.h"
#import <mach-o/dyld.h>
#import <mach/mach.h>
#import <dlfcn.h>
#import <stdio.h>
#import <string>

#import "JFCommon.h"
#import "Drawlm.h"
#import "JFPlayerPool.h"
#import "Drawdk.h"
#import "JFPropsPool.h"
#import "utf.h"
#import "Drawst.h"
#import "Offset.h"

#define IM_PI 3.14159265358979323846f
#define RAD2DEG( x )  ( (float)(x) * (float)(180.f / IM_PI) )
#define DEG2RAD( x ) ( (float)(x) * (float)(IM_PI / 180.f) )
#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
#define __fastcall

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height

using namespace std;
kaddr module = 0;
kaddr playerCameraManager = 0;
kaddr localPlayerController = 0;
kaddr controlRotation = 0;
kaddr BulletTrack = 0;
MinimalViewInfo POV;
kaddr STExtraShootWeapon = 0;
kaddr isAim = 0;
kaddr JumpZVelocity = 0;
kaddr ownerShootWeapon = 0;
kaddr BulletTracks = 0;
kaddr shootWeaponEntityComp = 0;
kaddr CurrentReloadWeapon = 0;
kaddr isScoopOpen = 0;
kaddr BulletTrack1 = 0;
kaddr UPawnMovementComponent = 0;

JFPlayer *bestAimPlayer = nil;
kaddr CameraCacheEntry = 0;
kaddr CameraCache = 0;

UIWindow *MainWindows = nil;
NSString *Value = nil;
NSString *VvGg = nil;

#pragma mark - Memory Reading & Writing
bool IsValidAddress(kaddr addr) {
    return addr > 0x100000000 && addr < 0x2000000000;
}

bool _read(kaddr addr, void *buffer, int len)
{
    if (!IsValidAddress(addr)) return false;
    vm_size_t size = 0;
    kern_return_t error = vm_read_overwrite(mach_task_self(), (vm_address_t)addr, len, (vm_address_t)buffer, &size);
    if(error != KERN_SUCCESS || size != len)
    {
        return false;
    }
    return true;
}

bool _write(kaddr addr, void *buffer, int len)
{
    if (!IsValidAddress(addr)) return false;
    kern_return_t error = vm_write(mach_task_self(), (vm_address_t)addr, (vm_offset_t)buffer, (mach_msg_type_number_t)len);
    if(error != KERN_SUCCESS)
    {
        return false;
    }
    return true;
}

kaddr GetRealOffset(kaddr offset) {
    if (module == 0) {
        module = (kaddr)_dyld_get_image_vmaddr_slide(0);
    }
    return (module + offset);
}

template<typename T> T Read(kaddr address) {
    T data{};
    _read(address, reinterpret_cast<void *>(&data), sizeof(T));
    return data;
}

template<typename T> void Write(kaddr address, T data) {
    _write(address, reinterpret_cast<void *>(&data), sizeof(T));
}

template<typename T> T *ReadArr(kaddr address, unsigned int size) {
    T data[size];
    T *ptr = data;
    _read(address, reinterpret_cast<void *>(ptr), (sizeof(T) * size));
    return ptr;
}

string ReadStr2(kaddr address, unsigned int size) {
    string name(size, '\0');
    _read(address, (void *) name.data(), size * sizeof(char));
    name.shrink_to_fit();
    return name;
}

kaddr GetPtr(kaddr address) {
    return Read<kaddr>(address);
}

string getUEString(kaddr address) {
    if (!IsValidAddress(address)) return "";
    unsigned int MAX_SIZE = 100;
    string uestring(ReadStr2(address, MAX_SIZE));
    uestring.shrink_to_fit();
    return uestring;
}

string GetFName(kaddr actorAddress) {
    if (!IsValidAddress(actorAddress)) return "";
    UInt32 FNameID = Read<UInt32>(actorAddress + 0x18);
    
    kaddr gname_1 = GetRealOffset(offset::GName_Func);
    kaddr gname_2 = GetRealOffset(offset::GName_Data);
    if (!IsValidAddress(gname_1)) return "";
    
    auto TNameEntryArray = reinterpret_cast<long(__fastcall*)(kaddr)>(gname_1)(gname_2);
    if (!IsValidAddress(TNameEntryArray)) return "";
    
    kaddr FNameEntryArr = GetPtr(TNameEntryArray + ((FNameID / 0x4000) * 8));
    if (!IsValidAddress(FNameEntryArr)) return "";
    
    kaddr FNameEntry = GetPtr(FNameEntryArr + ((FNameID % 0x4000) * 8));
    if (!IsValidAddress(FNameEntry)) return "";
    
    return getUEString(FNameEntry + offset::FNameEntry_);
}

#pragma mark - String Matching
bool isEqual(string s1, const char* check) {
    string s2(check);
    return (s1 == s2);
}

bool isEqual(string s1, string s2) {
    return (s1 == s2);
}

bool isContain(string str, const char* check) {
    size_t found = str.find(check);
    return (found != string::npos);
}

#pragma mark - Name Filter Helpers
bool isPlayer(string FName) {
    return isContain(FName, "BP_TrainPlayerPawn") || isContain(FName, "BP_PlayerPawn") || isContain(FName, "PlayerCharacter");
}

string getVehicleWithFName(string FName) {
    if (isContain(FName, "VH_Scooter_")) return "Car_Scooter";
    if (isContain(FName, "VH_Dacia_")) return "Car_Dacia";
    if (isContain(FName, "VH_Motorcycle_")) return "Car_Motorcycl";
    if (isContain(FName, "VH_MotorcycleCart_")) return "Car_MotorcycleCart";
    if (isContain(FName, "BP_VH_Tuk_")) return "Car_Tuk";
    if (isContain(FName, "BP_VH_Buggy_")) return "Car_Buggy";
    if (isContain(FName, "PickUp_0")) return "Car_PickUp";
    if (isContain(FName, "Mirado_")) return "Car_Mirado";
    if (isContain(FName, "VH_MiniBus_")) return "Car_MiniBus";
    if (isContain(FName, "VH_BRDM_")) return "Car_BRDM";
    if (isContain(FName, "VH_UAZ")) return "Car_UAZ";
    return "";
}

string getM416WithFName(string FName) {
    if (isContain(FName, "BP_Rifle_M416_Wrapper_C")) return "Rifle_M416";
    return "";
}

string getakmWithFName(string FName) {
    if (isContain(FName, "BP_Rifle_AKM_Wrapper_C")) return "Rifle_AKM";
    return "";
}

string getSCARWithFName(string FName) {
    if (isContain(FName, "BP_Rifle_SCAR_Wrapper_C")) return "Rifle_SCAR";
    return "";
}

string getVALWithFName(string FName) {
    if (isContain(FName, "BP_Rifle_VAL_Wrapper_C")) return "Rifle_VAL";
    return "";
}

string getQBZWithFName(string FName) {
    if (isContain(FName, "BP_Rifle_QBZ_Wrapper_C")) return "Rifle_QBZ";
    return "";
}

string getM7WithFName(string FName) {
    if (isContain(FName, "BP_Rifle_M762_Wrapper_C")) return "Rifle_M762";
    return "";
}

string getVectorWithFName(string FName) {
    if (isContain(FName, "BP_MachineGun_Vector_Wrapper_C")) return "Rifle_Vector";
    return "";
}

string getWeaponWithFName(string FName) {
    if (isContain(FName, "BP_Sniper_Kar98k_Wrapper_C")) return "Sniper_Kar98k";
    if (isContain(FName, "BP_Sniper_Mini14_Wrapper_C")) return "Sniper_Mini14";
    return "";
}

string getArmorWithFName(string FName) {
    if (isContain(FName, "PickUp_BP_Helmet_Lv2_C") || isEqual(FName, "PickUp_BP_Helmet_Lv2_A_C") || isEqual(FName, "PickUp_BP_Helmet_Lv2_B_C")) return "Helmet_Lv2";
    if (isContain(FName, "PickUp_BP_Armor_Lv2_C") || isEqual(FName, "PickUp_BP_Armor_Lv2_A_C") || isEqual(FName, "PickUp_BP_Armor_Lv2_B_C")) return "Armor_Lv2";
    if (isContain(FName, "PickUp_BP_Bag_Lv2_C") || isEqual(FName, "PickUp_BP_Bag_Lv2_A_C") || isEqual(FName, "PickUp_BP_Bag_Lv2_B_C")) return "Bag_Lv2";
    if (isContain(FName, "PickUp_BP_Helmet_Lv3_C") || isEqual(FName, "PickUp_BP_Helmet_Lv3_A_C") || isEqual(FName, "PickUp_BP_Helmet_Lv3_B_C")) return "Helmet_Lv3";
    if (isContain(FName, "PickUp_BP_Armor_Lv3_C") || isEqual(FName, "PickUp_BP_Armor_Lv3_A_C") || isEqual(FName, "PickUp_BP_Armor_Lv3_B_C")) return "Armor_Lv3";
    return "";
}

string getSightWithFName(string FName) {
    if (isContain(FName, "BP_MZJ_3X_Pickup_C")) return "Scoop-3X";
    return "";
}

string get4xWithFName(string FName) {
    if (isContain(FName, "BP_MZJ_4X_Pickup_C")) return "Scoop-4X";
    return "";
}

string get6xWithFName(string FName) {
    if (isContain(FName, "BP_MZJ_6X_Pickup_C")) return "Scoop-6X";
    return "";
}

string get8xWithFName(string FName) {
    if (isContain(FName, "BP_MZJ_8X_Pickup_C")) return "Scoop-8X";
    return "";
}

string getAccessoryWithFName(string FName) {
    if (isContain(FName, "BP_QK_Mid_Compensator_Pickup_C")) return "Mid";
    if (isContain(FName, "BP_QK_Large_Compensator_Pickup_C")) return "Large";
    if (isContain(FName, "BP_QT_UZI_Pickup_C")) return "UZI_Pickup";
    if (isContain(FName, "BP_WB_LightGrip_Pickup_C")) return "LightGrip";
    return "";
}

string getBulletWithFName(string FName) {
    if (isContain(FName, "BP_Ammo_762mm_Pickup_C")) return "Ammo_762mm";
    if (isContain(FName, "BP_Ammo_556mm_Pickup_C")) return "Ammo_556mm";
    return "";
}

string getDrugWithFName(string FName) {
    if (isContain(FName, "Injection_Pickup_C")) return "9Injection";
    if (isContain(FName, "Firstaid_Pickup_C")) return "Firstaid";
    return "";
}

string getBoxWithFName(string FName) {
    if (isContain(FName, "PickUpListWrapperActor")) return "Box_Noob";
    return "";
}

string getWrapperWithFName(string FName) {
    if (isContain(FName, "BP_Pistol_Flaregun_Wrapper_C")) return "Flaregun";
    return "";
}

string getEarlyWarningWithFName(string FName) {
    if (isContain(FName, "ProjGrenade_BP_C")) return "Grenade";
    if (isContain(FName, "BP_Grenade_Shoulei_C")) return "Grenade!";
    return "";
}

#pragma mark - Matrix & Vector Math
Vector3 MatrixToVector(FMatrix matrix) {
    return Vector3(matrix[3][0], matrix[3][1], matrix[3][2]);
}

FMatrix MatrixMulti(FMatrix m1, FMatrix m2) {
    FMatrix matrix = FMatrix();
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            for (int k = 0; k < 4; k++) {
                matrix[i][j] += m1[i][k] * m2[k][j];
            }
        }
    }
    return matrix;
}

FMatrix TransformToMatrix(FTransform transform) {
    FMatrix matrix;
    matrix[3][0] = transform.Translation.X;
    matrix[3][1] = transform.Translation.Y;
    matrix[3][2] = transform.Translation.Z;
    
    float x2 = transform.Rotation.x + transform.Rotation.x;
    float y2 = transform.Rotation.y + transform.Rotation.y;
    float z2 = transform.Rotation.z + transform.Rotation.z;
    
    float xx2 = transform.Rotation.x * x2;
    float yy2 = transform.Rotation.y * y2;
    float zz2 = transform.Rotation.z * z2;
    
    matrix[0][0] = (1.0f - (yy2 + zz2)) * transform.Scale3D.X;
    matrix[1][1] = (1.0f - (xx2 + zz2)) * transform.Scale3D.Y;
    matrix[2][2] = (1.0f - (xx2 + yy2)) * transform.Scale3D.Z;
    
    float yz2 = transform.Rotation.y * z2;
    float wx2 = transform.Rotation.w * x2;
    matrix[2][1] = (yz2 - wx2) * transform.Scale3D.Z;
    matrix[1][2] = (yz2 + wx2) * transform.Scale3D.Y;
    
    float xy2 = transform.Rotation.x * y2;
    float wz2 = transform.Rotation.w * z2;
    matrix[1][0] = (xy2 - wz2) * transform.Scale3D.Y;
    matrix[0][1] = (xy2 + wz2) * transform.Scale3D.X;
    
    float xz2 = transform.Rotation.x * z2;
    float wy2 = transform.Rotation.w * y2;
    matrix[2][0] = (xz2 + wy2) * transform.Scale3D.Z;
    matrix[0][2] = (xz2 - wy2) * transform.Scale3D.X;
    
    matrix[0][3] = 0;
    matrix[1][3] = 0;
    matrix[2][3] = 0;
    matrix[3][3] = 1;
    
    return matrix;
}

FMatrix RotatorToMatrix(FRotator rotation) {
    float radPitch = rotation.Pitch * ((float) M_PI / 180.0f);
    float radYaw = rotation.Yaw * ((float) M_PI / 180.0f);
    float radRoll = rotation.Roll * ((float) M_PI / 180.0f);
    
    float SP = sinf(radPitch);
    float CP = cosf(radPitch);
    float SY = sinf(radYaw);
    float CY = cosf(radYaw);
    float SR = sinf(radRoll);
    float CR = cosf(radRoll);
    
    FMatrix matrix;
    matrix[0][0] = (CP * CY);
    matrix[0][1] = (CP * SY);
    matrix[0][2] = (SP);
    matrix[0][3] = 0;
    
    matrix[1][0] = (SR * SP * CY - CR * SY);
    matrix[1][1] = (SR * SP * SY + CR * CY);
    matrix[1][2] = (-SR * CP);
    matrix[1][3] = 0;
    
    matrix[2][0] = (-(CR * SP * CY + SR * SY));
    matrix[2][1] = (CY * SR - CR * SP * SY);
    matrix[2][2] = (CR * CP);
    matrix[2][3] = 0;
    
    matrix[3][0] = 0;
    matrix[3][1] = 0;
    matrix[3][2] = 0;
    matrix[3][3] = 1;
    
    return matrix;
}

Vector2 WorldToScreen(Vector3 worldLocation, MinimalViewInfo camViewInfo, int width, int height) {
    FMatrix tempMatrix = RotatorToMatrix(camViewInfo.Rotation);
    Vector3 vAxisX(tempMatrix[0][0], tempMatrix[0][1], tempMatrix[0][2]);
    Vector3 vAxisY(tempMatrix[1][0], tempMatrix[1][1], tempMatrix[1][2]);
    Vector3 vAxisZ(tempMatrix[2][0], tempMatrix[2][1], tempMatrix[2][2]);
    
    Vector3 vDelta = worldLocation - camViewInfo.Location;
    Vector3 vTransformed(Vector3::Dot(vDelta, vAxisY), Vector3::Dot(vDelta, vAxisZ), Vector3::Dot(vDelta, vAxisX));
    
    if (vTransformed.Z < 1.0f) {
        vTransformed.Z = 1.0f;
    }
    
    float fov = camViewInfo.FOV;
    float screenCenterX = (width / 2.0f);
    float screenCenterY = (height / 2.0f);
    
    return Vector2(
        (screenCenterX + vTransformed.X * (screenCenterX / tanf(fov * ((float) M_PI / 360.0f))) / vTransformed.Z),
        (screenCenterY - vTransformed.Y * (screenCenterX / tanf(fov * ((float) M_PI / 360.0f))) / vTransformed.Z)
    );
}

FRotator ToRotator(Vector3 local, Vector3 target) {
    Vector3 rotation = local - target;
    FRotator newViewAngle = {0};
    float hyp = sqrt(rotation.X * rotation.X + rotation.Y * rotation.Y);
    
    newViewAngle.Pitch = -atan(rotation.Z / hyp) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Yaw = atan(rotation.Y / rotation.X) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Roll = 0.0f;
    
    if (rotation.X >= 0.0f)
        newViewAngle.Yaw += 180.0f;
    
    return newViewAngle;
}

#pragma mark - IFuckYou Implementation
@interface IFuckYou ()

@property (nonatomic, strong) NSTimer *dataTimer;
@property (nonatomic, strong) NSTimer *actionTimer;

- (void)aimbot;
- (void)aimbot2;
- (void)bullet;
- (void)Auto;
- (void)modifyWeaponData;
- (void)modifyWeaponData1;
- (void)filterBestAimPlayer1;
- (void)filterBestAimPlayerb;

@end

@implementation IFuckYou

- (instancetype)init
{
    if (self = [super init]) {
        self.playerList = [NSMutableArray array];
        self.propsList = [NSMutableArray array];
        self.playerPool = [[JFPlayerPool alloc] init];
        self.propsPool = [[JFPropsPool alloc] init];
        
        self.localPlayer = [self.playerPool getObjFromPool];
        self.localPlayer.type = PlayerTypeMyself;
    }
    return self;
}

static IFuckYou *instance = nil;

+ (IFuckYou *)getInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

+ (id)allocWithZone:(struct _NSZone*)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

static UIWindow *gOverlayWindow = nil;

- (void)entry
{
    module = (kaddr)_dyld_get_image_vmaddr_slide(0);
    
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!gOverlayWindow) {
            if (@available(iOS 13.0, *)) {
                UIWindowScene *activeScene = nil;
                for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
                    if (scene.activationState == UISceneActivationStateForegroundActive && [scene isKindOfClass:[UIWindowScene class]]) {
                        activeScene = (UIWindowScene *)scene;
                        break;
                    }
                }
                if (activeScene) {
                    gOverlayWindow = [[UIWindow alloc] initWithWindowScene:activeScene];
                } else {
                    gOverlayWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
                }
            } else {
                gOverlayWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
            }
            
            gOverlayWindow.windowLevel = UIWindowLevelStatusBar + 100.0f;
            gOverlayWindow.backgroundColor = [UIColor clearColor];
            gOverlayWindow.hidden = NO;
            gOverlayWindow.userInteractionEnabled = YES;
            
            UIViewController *rootVC = [[UIViewController alloc] init];
            rootVC.view.backgroundColor = [UIColor clearColor];
            rootVC.view.userInteractionEnabled = YES;
            gOverlayWindow.rootViewController = rootVC;
            
            [rootVC.view addSubview:self.overlayView];
            [rootVC.view addSubview:self.floatingMenuView];
            
            [gOverlayWindow makeKeyAndVisible];
            
            self.floatingMenuView.hidden = NO;
            self.floatingMenuView.alpha = 1.0f;
        }
        
        [self startFuckYou];
    });
}

- (void)startFuckYou
{
    [self cancelTimer];
    self.dataTimer = [NSTimer timerWithTimeInterval:1.0f/60 target:self selector:@selector(readData) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.dataTimer forMode:NSRunLoopCommonModes];
    
    self.actionTimer = [NSTimer timerWithTimeInterval:1.0f/60 target:self selector:@selector(localPlayerAction) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.actionTimer forMode:NSRunLoopCommonModes];
}

- (void)cancelTimer
{
    if (self.dataTimer) {
        [self.dataTimer invalidate];
        self.dataTimer = nil;
    }
    if (self.actionTimer) {
        [self.actionTimer invalidate];
        self.actionTimer = nil;
    }
    [self recyclePlayer];
}

- (void)recyclePlayer
{
    for (JFPlayer *player in self.playerList) {
        [self.playerPool putObj2Pool:player];
    }Yeh lijiye **`Drawzb.mm`** ka complete updated code, jisme independent top-level `UIWindow` (`windowLevel = UIWindowLevelStatusBar + 100.0f`) ka logic lagaya gaya hai taaki menu game ki 3D graphics ke peechhe na chhipe aur screen par 100% show ho:

```objc
#import "Drawzb.h"
#import <mach-o/dyld.h>
#import <mach/mach.h>
#import <dlfcn.h>
#import <stdio.h>
#import <string>

#import "JFCommon.h"
#import "Drawlm.h"
#import "JFPlayerPool.h"
#import "Drawdk.h"
#import "JFPropsPool.h"
#import "utf.h"
#import "Drawst.h"
#import "Offset.h"

#define IM_PI 3.14159265358979323846f
#define RAD2DEG( x )  ( (float)(x) * (float)(180.f / IM_PI) )
#define DEG2RAD( x ) ( (float)(x) * (float)(IM_PI / 180.f) )
#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
#define __fastcall

using namespace std;
kaddr module = 0;
kaddr playerCameraManager = 0;
kaddr localPlayerController = 0;
kaddr controlRotation = 0;
MinimalViewInfo POV;

static UIWindow *gOverlayWindow = nil;

#pragma mark - Memory Reading & Writing
bool IsValidAddress(kaddr addr) {
    return addr > 0x100000000 && addr < 0x2000000000;
}

bool _read(kaddr addr, void *buffer, int len)
{
    if (!IsValidAddress(addr)) return false;
    vm_size_t size = 0;
    kern_return_t error = vm_read_overwrite(mach_task_self(), (vm_address_t)addr, len, (vm_address_t)buffer, &size);
    if(error != KERN_SUCCESS || size != len) return false;
    return true;
}

bool _write(kaddr addr, void *buffer, int len)
{
    if (!IsValidAddress(addr)) return false;
    kern_return_t error = vm_write(mach_task_self(), (vm_address_t)addr, (vm_offset_t)buffer, (mach_msg_type_number_t)len);
    if(error != KERN_SUCCESS) return false;
    return true;
}

kaddr GetRealOffset(kaddr offset) {
    if (module == 0) {
        module = (kaddr)_dyld_get_image_vmaddr_slide(0);
    }
    return (module + offset);
}

template<typename T> T Read(kaddr address) {
    T data{};
    _read(address, reinterpret_cast<void *>(&data), sizeof(T));
    return data;
}

template<typename T> void Write(kaddr address, T data) {
    _write(address, reinterpret_cast<void *>(&data), sizeof(T));
}

kaddr GetPtr(kaddr address) {
    return Read<kaddr>(address);
}

string getUEString(kaddr address) {
    if (!IsValidAddress(address)) return "";
    unsigned int MAX_SIZE = 100;
    string name(MAX_SIZE, '\0');
    _read(address, (void *) name.data(), MAX_SIZE * sizeof(char));
    name.shrink_to_fit();
    return name;
}

string GetFName(kaddr actorAddress) {
    if (!IsValidAddress(actorAddress)) return "";
    UInt32 FNameID = Read<UInt32>(actorAddress + 0x18);
    
    kaddr gname_1 = GetRealOffset(offset::GName_Func);
    kaddr gname_2 = GetRealOffset(offset::GName_Data);
    if (!IsValidAddress(gname_1)) return "";
    
    auto TNameEntryArray = reinterpret_cast<long(__fastcall*)(kaddr)>(gname_1)(gname_2);
    if (!IsValidAddress(TNameEntryArray)) return "";
    
    kaddr FNameEntryArr = GetPtr(TNameEntryArray + ((FNameID / 0x4000) * 8));
    if (!IsValidAddress(FNameEntryArr)) return "";
    
    kaddr FNameEntry = GetPtr(FNameEntryArr + ((FNameID % 0x4000) * 8));
    if (!IsValidAddress(FNameEntry)) return "";
    
    return getUEString(FNameEntry + offset::FNameEntry_);
}

bool isPlayer(string FName) {
    return (FName.find("BP_TrainPlayerPawn") != string::npos || FName.find("BP_PlayerPawn") != string::npos || FName.find("PlayerCharacter") != string::npos);
}

#pragma mark - IFuckYou Implementation
@interface IFuckYou ()
@property (nonatomic, strong) NSTimer *dataTimer;
@property (nonatomic, strong) NSTimer *actionTimer;
@end

@implementation IFuckYou

- (instancetype)init
{
    if (self = [super init]) {
        self.playerList = [NSMutableArray array];
        self.propsList = [NSMutableArray array];
        self.playerPool = [[JFPlayerPool alloc] init];
        self.propsPool = [[JFPropsPool alloc] init];
        self.localPlayer = [self.playerPool getObjFromPool];
        self.localPlayer.type = PlayerTypeMyself;
    }
    return self;
}

static IFuckYou *instance = nil;

+ (IFuckYou *)getInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (void)entry
{
    module = (kaddr)_dyld_get_image_vmaddr_slide(0);
    
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!gOverlayWindow) {
            if (@available(iOS 13.0, *)) {
                UIWindowScene *activeScene = nil;
                for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
                    if (scene.activationState == UISceneActivationStateForegroundActive && [scene isKindOfClass:[UIWindowScene class]]) {
                        activeScene = (UIWindowScene *)scene;
                        break;
                    }
                }
                if (activeScene) {
                    gOverlayWindow = [[UIWindow alloc] initWithWindowScene:activeScene];
                } else {
                    gOverlayWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
                }
            } else {
                gOverlayWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
            }
            
            gOverlayWindow.windowLevel = UIWindowLevelStatusBar + 100.0f;
            gOverlayWindow.backgroundColor = [UIColor clearColor];
            gOverlayWindow.hidden = NO;
            gOverlayWindow.userInteractionEnabled = YES;
            
            UIViewController *rootVC = [[UIViewController alloc] init];
            rootVC.view.backgroundColor = [UIColor clearColor];
            rootVC.view.userInteractionEnabled = YES;
            gOverlayWindow.rootViewController = rootVC;
            
            [rootVC.view addSubview:self.overlayView];
            [rootVC.view addSubview:self.floatingMenuView];
            
            [gOverlayWindow makeKeyAndVisible];
            
            self.floatingMenuView.hidden = NO;
            self.floatingMenuView.alpha = 1.0f;
        }
        
        [self startLoop];
    });
}

- (void)startLoop
{
    if (self.dataTimer) {
        [self.dataTimer invalidate];
    }
    self.dataTimer = [NSTimer timerWithTimeInterval:1.0f/60 target:self selector:@selector(readData) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.dataTimer forMode:NSRunLoopCommonModes];
}

- (void)readData
{
    // Memory loop hook placeholder
}

- (JFFloatingMenuView *)floatingMenuView
{
    if (!_floatingMenuView) {
        _floatingMenuView = [[JFFloatingMenuView alloc] initWithFrame:CGRectMake(489, 58, 45, 45)];
    }
    return _floatingMenuView;
}

- (JFOverlayView *)overlayView
{
    if (!_overlayView) {
        _overlayView = [[JFOverlayView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    }
    return _overlayView;
}

@end

static void __attribute__((constructor)) initializeTweak() {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[IFuckYou getInstance] entry];
    });
}