namespace offset {

// === Latest Version Global Addresses ===
long GWorld1 = 0x10C034388;               // Updated: Naya UWorld Core Address
long GWorld2 = 0x10AA11EA0;               // Updated: Naya GWorld Data Pointer
long GName1 =  0x10A5BD5F0;               // Updated: Naya GName Data Pointer
long GName2 =  0x105014128;               // Updated: Naya GName Function Pointer
long LineOfSightTo_Func = 0x1062126D4;    // Updated: Naya LineOfSight Function Address

long FNameEntry_ = 0x0;                   // Updated: Manual Entry Data

// === Read Local Player Info / World Structures ===
long ULevel_ = 0x30;                      // Standard: UWorld.PersistentLevel
long ActorArray_ = 0xE0;                  // Updated: ULevel.ActorCluster (From New SDK Structure)
long ActorCount_ = 0xE8;                  // Updated: ActorCluster Array Count (0xE0 + 8 Bytes)
long NetDriver_ = 0x38;                   // Updated: UWorld.NetDriver
long ServerConnection_ = 0x78;            // Updated: UNetDriver.ServerConnection
long localPlayerController_ = 0x98;       // Updated: UNetConnection.OwningActor
long LocalPlayerBase_ = 0x4B8;            // Updated: AGameStateBase.AuthorityGameMode

// === Weapon Offsets ===
long bIsWeaponFiring_ = 0x1830;           // Updated: ASTExtraBaseCharacter.bIsWeaponFiring
long weaponManagerComponent_ = 0x2608;    // Updated: ASTExtraBaseCharacter.WeaponManagerComponent
long CurrentReloadWeapon_ = 0x3200;       // Updated: ASTExtraBaseCharacter.CurrentReloadWeapon
long cachedCurUseWeapon1_ = 0x368;        // Updated: UWeaponManagerComponent.LocalBackpackCurrentWeaponFinishDelegate
long cachedCurUseWeapon_ = 0x5D8;         // Updated: UWeaponManagerComponent.CurrentWeaponReplicated
long shootWeaponComponent_ = 0xF90;       // Updated: ASTExtraShootWeapon.ShootWeaponComponent
long ownerShootWeapon_ = 0x2D0;           // Updated: USTExtraShootWeaponComponent.OwnerShootWeapon

// === Camera & Rotation ===
long playerCameraManager_ = 0x548;        // Updated: APlayerController.PlayerCameraManager
long POV_ = 0x10A0 + 0x10;                // Updated: ViewTarget + 0x10 (POV inside FTViewTarget)
long controlRotation_ = 0x4E0;            // Updated: AController.ControlRotation

// === Read Player Info (ESP / Math) ===
long rootComponent_ = 0x208;              // Updated: AActor.RootComponent
long PlayerWorldPos_ = 0x1C8;             // Updated: Manual (Relative Location World Space)
long PlayerHP_ = 0xE60;                   // Updated: ASTExtraCharacter.Health
long PlayerMaxHP_ = 0xE64;                // Updated: ASTExtraCharacter.HealthMax
long playerIsDead_ = 0xE7C;               // Updated: ASTExtraCharacter.bDead
long playerState_ = 0x1058;               // Updated: ASTExtraCharacter.CurrentStates
long nameAddr_ = 0x960;                   // Updated: AUAECharacter.PlayerName
long playerPlayerKey_ = 0x988;            // Updated: AUAECharacter.PlayerUID
long playerIsAI_ = 0xA40;                 // Updated: AUAECharacter.bIsAI
long playerTeamNo_ = 0x998;               // Updated: AUAECharacter.TeamID

// === Mesh & Skeleton ESP ===
long mesh_ = 0x510;                       // Updated: ACharacter.Mesh (Skeleton Core)
long mymesh_ = 0x510;                     // Updated: ACharacter.Mesh
long FTransform_ = 0x208;                 // Updated: AActor.RootComponent
long boneArray_ = 0x9A8;                  // Updated: UOceanMeshComponent.ShapeUniformValue

}
