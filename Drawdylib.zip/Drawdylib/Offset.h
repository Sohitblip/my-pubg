#pragma once
#include <stdint.h>

typedef uintptr_t kaddr;

namespace offset {

    // === Latest Version Global Addresses ===
    static const kaddr GWorld_Func        = 0x10C034388; // GWorld1: UWorld Core Address
    static const kaddr GWorld_Data        = 0x10AA11EA0; // GWorld2: GWorld Data Pointer
    static const kaddr GName_Data         = 0x10A5BD5F0; // GName1: GName Data Pointer
    static const kaddr GName_Func         = 0x105014128; // GName2: GName Function Pointer
    static const kaddr LineOfSightTo_Func = 0x1062126D4; // LineOfSight Function Address
    static const kaddr FNameEntry_        = 0x0;         // Manual Entry Data

    // === Read Local Player Info / World Structures ===
    static const kaddr ULevel_            = 0x30;        // UWorld.PersistentLevel
    static const kaddr ActorArray_        = 0xE0;        // ULevel.ActorCluster
    static const kaddr ActorCount_        = 0xE8;        // ActorCluster Array Count (0xE0 + 8 Bytes)
    static const kaddr NetDriver_         = 0x38;        // UWorld.NetDriver
    static const kaddr ServerConnection_  = 0x78;        // UNetDriver.ServerConnection
    static const kaddr localPlayerController_ = 0x98;    // UNetConnection.OwningActor
    static const kaddr LocalPlayerBase_   = 0x4B8;       // AGameStateBase.AuthorityGameMode

    // === Weapon Offsets ===
    static const kaddr bIsWeaponFiring_        = 0x1830; // ASTExtraBaseCharacter.bIsWeaponFiring
    static const kaddr weaponManagerComponent_ = 0x2608; // ASTExtraBaseCharacter.WeaponManagerComponent
    static const kaddr CurrentReloadWeapon_    = 0x3200; // ASTExtraBaseCharacter.CurrentReloadWeapon
    static const kaddr cachedCurUseWeapon1_    = 0x368;  // UWeaponManagerComponent.LocalBackpackCurrentWeaponFinishDelegate
    static const kaddr cachedCurUseWeapon_     = 0x5D8;  // UWeaponManagerComponent.CurrentWeaponReplicated
    static const kaddr shootWeaponComponent_   = 0xF90;  // ASTExtraShootWeapon.ShootWeaponComponent
    static const kaddr ownerShootWeapon_       = 0x2D0;  // USTExtraShootWeaponComponent.OwnerShootWeapon

    // === Camera & Rotation ===
    static const kaddr playerCameraManager_    = 0x548;  // APlayerController.PlayerCameraManager
    static const kaddr POV_                    = 0x10A0 + 0x10; // ViewTarget + 0x10 (POV inside FTViewTarget)
    static const kaddr controlRotation_        = 0x4E0;  // AController.ControlRotation

    // === Read Player Info (ESP / Math) ===
    static const kaddr rootComponent_          = 0x208;  // AActor.RootComponent
    static const kaddr PlayerWorldPos_         = 0x1C8;  // Manual (Relative Location World Space)
    static const kaddr PlayerHP_               = 0xE60;  // ASTExtraCharacter.Health
    static const kaddr PlayerMaxHP_            = 0xE64;  // ASTExtraCharacter.HealthMax
    static const kaddr playerIsDead_           = 0xE7C;  // ASTExtraCharacter.bDead
    static const kaddr playerState_            = 0x1058; // ASTExtraCharacter.CurrentStates
    static const kaddr nameAddr_               = 0x960;  // AUAECharacter.PlayerName
    static const kaddr playerPlayerKey_        = 0x988;  // AUAECharacter.PlayerUID
    static const kaddr playerIsAI_             = 0xA40;  // AUAECharacter.bIsAI
    static const kaddr playerTeamNo_           = 0x998;  // AUAECharacter.TeamID

    // === Mesh & Skeleton ESP ===
    static const kaddr mesh_                   = 0x510;  // ACharacter.Mesh (Skeleton Core)
    static const kaddr mymesh_                 = 0x510;  // ACharacter.Mesh
    static const kaddr FTransform_             = 0x208;  // AActor.RootComponent
    static const kaddr boneArray_              = 0x9A8;  // UOceanMeshComponent.ShapeUniformValue

}