#import "GuiRenderer.h"
#import <Metal/Metal.h>

#include "imgui.h"
#include "imgui_impl_metal.h"

#if TARGET_OS_OSX
#include "imgui_impl_osx.h"
#endif

@interface GuiRenderer ()
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@property (nonatomic, strong) MTKTextureLoader *loader;
@end

@implementation GuiRenderer

-(nonnull instancetype)initWithView:(nonnull MTKView *)view;
{
    self = [super init];
    if(self)
    {
        _device = view.device;
        _commandQueue = [_device newCommandQueue];
        _loader = [[MTKTextureLoader alloc] initWithDevice: _device];
        
        // Ensure MTKView renders continuously without pausing
        view.paused = NO;
        view.enableSetNeedsDisplay = NO;
    }
    return self;
}

- (void)drawInMTKView:(MTKView *)view
{
    if (ImGui::GetCurrentContext() == NULL) {
        return;
    }

    ImGuiIO &io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

#if TARGET_OS_OSX
    CGFloat framebufferScale = view.window.screen.backingScaleFactor ?: NSScreen.mainScreen.backingScaleFactor;
#else
    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
#endif
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);

    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    if (!commandBuffer) return;

    MTLRenderPassDescriptor *renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil)
    {
        // Clear background to fully transparent
        renderPassDescriptor.colorAttachments[0].clearColor = MTLClearColorMake(0.0f, 0.0f, 0.0f, 0.0f);
        renderPassDescriptor.colorAttachments[0].loadAction = MTLLoadActionClear;
        renderPassDescriptor.colorAttachments[0].storeAction = MTLStoreActionStore;

        id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        [renderEncoder pushDebugGroup:@"AstonCheatsGUI"];

        // Start the Dear ImGui frame safely
        ImGui_ImplMetal_NewFrame(renderPassDescriptor);
#if TARGET_OS_OSX
        ImGui_ImplOSX_NewFrame(view);
#endif
        ImGui::NewFrame();

        if (self.delegate && [self.delegate respondsToSelector:@selector(draw)]) {
            [self.delegate draw];
        }

        // Rendering execution
        ImGui::Render();
        ImDrawData *drawData = ImGui::GetDrawData();
        if (drawData) {
            ImGui_ImplMetal_RenderDrawData(drawData, commandBuffer, renderEncoder);
        }

        [renderEncoder popDebugGroup];
        [renderEncoder endEncoding];

        if (view.currentDrawable) {
            [commandBuffer presentDrawable:view.currentDrawable];
        }
    }

    [commandBuffer commit];
}

- (void)mtkView:(MTKView *)view drawableSizeWillChange:(CGSize)size {
}

-(void)initializePlatform {
    if (ImGui::GetCurrentContext() == NULL) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
    }

    ImGui_ImplMetal_Init(_device);

    if (self.delegate && [self.delegate respondsToSelector:@selector(setup)]) {
        [self.delegate setup];
    }
}

-(void)shutdownPlatform {
    ImGui_ImplMetal_Shutdown();
#if TARGET_OS_OSX
    ImGui_ImplOSX_Shutdown();
#endif
}

#if TARGET_OS_OSX
-(bool)handleEvent:(NSEvent *_Nonnull)event view:(NSView *_Nullable)view {
    return ImGui_ImplOSX_HandleEvent(event, view);
}
#else
-(void)handleEvent:(UIEvent *_Nullable)event view:(UIView *_Nullable)view {
    NSSet *touches = event.allTouches;
    if (!touches || touches.count == 0) return;
    
    UITouch *anyTouch = touches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in touches) {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled) {
            hasActionTouch = YES; // fixed below
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}
#endif

-(id<MTLTexture>)loadTextureWithURL:(NSURL *)url {
    id<MTLTexture> texture = [self.loader newTextureWithContentsOfURL:url options:nil error:nil];
    return texture;
}

-(id<MTLTexture>)loadTextureWithName:(NSString *)name {
    id<MTLTexture> texture = [self.loader newTextureWithName:name scaleFactor:1.0 bundle:nil options:nil error:nil];
    return texture;
}

@end